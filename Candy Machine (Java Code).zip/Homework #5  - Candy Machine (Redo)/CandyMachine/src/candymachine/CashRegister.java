package candymachine;

/**
 *
 * @author Isaiah
 */
public class CashRegister extends Dispenser {
    protected double money;
    
    
    public CashRegister(String p1, double p1_price, int p1_inventory, String p2, double p2_price, int p2_inventory,
        String p3, double p3_price, int p3_inventory, String p4, double p4_price, int p4_inventory, double m){
        super(p1, p1_price, p1_inventory, p2, p2_price, p2_inventory, p3, p3_price, p3_inventory, p4, p4_price, p4_inventory);
        
        
        money = m;
        
        setMoney(money);
        
    }


 public void Money(double cust_m){
        cust_money = cust_m; 
        
        
        if(cust_m == product1_price && product1_inventory > 0){
           money = money + cust_m;
        }
        else if(cust_m > product1_price && product1_inventory > 0){
            money = (money + cust_m) - (cust_m - product1_price);
        }
    
        else if(cust_m > 0.00 && cust_m < product1_price){
            money = money + product1_price;
        }
        
        
    }
    public void Money2(double cust_m){
        cust_money = cust_m;
        
        if(cust_m > product2_price && product2_inventory > 0){
           money = (money + cust_m) - (cust_m - product2_price);
        }
        else if(cust_money == product2_price && product2_inventory > 0){
           money = money + cust_money;
        }
        else if(cust_m > 0.00 && cust_m < product2_price && cust_m == product1_price - cust_m){
            money = money + product2_price;
        }
        
    }
    
    public void Money3(double cust_m){
        cust_money = cust_m;
        
        if(cust_m == product3_price && product3_inventory > 0){
           money = money + cust_m;
        }
        else if(cust_m > product3_price && product3_inventory > 0){
           money = (money + cust_m) - (cust_m - product3_price);
        }
        else if(cust_m > 0.00 && cust_m < product3_price){
            money = money + product3_price;
        }
        
        
    }
    
    public void Money4(double cust_m){
        cust_money = cust_m;
        
        if(cust_m == product4_price && product4_inventory > 0){
           money = money + cust_m;
        }
        else if(cust_m > product4_price && product4_inventory > 0){
           money = (money + cust_m) - (cust_m - product4_price);
        }
        else if(cust_m > 0.00 && cust_m < product4_price){
            money = money + product4_price;
        }
        
      
    }
    
    public void addMoney(double moneys){
        money = money + moneys;
     }
    
    public void subMoney(double moneys){
        money = money - moneys;
    }
    

    public double getMoney(){
        return money;
    }
    
    public void setMoney(double m){
        this.money = m;
    }
     
   
        
}
