
package candymachine;
import java.util.Scanner;

/**
 *
 * @author Isaiah
 */
public class Dispenser extends CandyMachine {
    protected double cust_money;
    
    public Dispenser(String p1, double p1_price, int p1_inventory, String p2, double p2_price, int p2_inventory,
        String p3, double p3_price, int p3_inventory, String p4, double p4_price, int p4_inventory){
        super(p1, p1_price, p2, p2_price, p3, p3_price, p4, p4_price);
         
    
    product1_inventory = p1_inventory;
    product2_inventory = p2_inventory;
    product3_inventory = p3_inventory;
    product4_inventory = p4_inventory;
    
    
   
    setproduct1_Inventory(p1_inventory);
    setproduct2_Inventory(p2_inventory);
    setproduct3_Inventory(p3_inventory);
    setproduct4_Inventory(p4_inventory);
    
    
    
    }
    
   
public double getCustMoney(){
   return cust_money;
}

public void setCustMoney(double cust_m){
    this.cust_money = cust_m;
    
    Scanner input = new Scanner(System.in);
    
    if(cust_m == product1_price && product1_inventory > 0){
       System.out.println("Dispensing " + product1 + "."); 
       product1_inventory--;
      
    }
    else if(cust_m < product1_price && product1_inventory > 0){
       System.out.println("Insufficient funds. Please add " + "$" + (product1_price - cust_m));
       System.out.println();
       System.out.print("Please input the remaining funds: $");
       double funds = input.nextDouble();
       if(funds == (product1_price - cust_m)){
          System.out.println("Dispensing " + product1 + "."); 
          product1_inventory--; 
       }
       
    }
    else if(cust_m > product1_price && product1_inventory > 0){
        System.out.println("Dispensing " + product1 + ".");
        System.out.println("Your change is: " + "$" + (cust_m - product1_price));
        product1_inventory--;
    }
    else{
        product1_inventory = 0;
        System.out.println("This product is currently unavailable.");
        System.out.println("Returning your money...");
    }
    
}

public void setCustMoney2(double cust_m){
    this.cust_money = cust_m;
    Scanner input = new Scanner(System.in);
    
    if(cust_m == product2_price && product2_inventory > 0){
       System.out.println("Dispensing " + product2 + "."); 
       product2_inventory--;
    }
    else if(cust_m < product2_price && product2_inventory > 0){
       System.out.println("Insufficient funds. Please add " + "$" + (product2_price - cust_m));
       System.out.println();
       System.out.print("Please input the remaining funds: $");
       double funds = input.nextDouble();
       if(funds == (product2_price - cust_m)){
          System.out.println("Dispensing " + product2 + "."); 
          product2_inventory--; 
           
       }
    }
    else if(cust_m > product2_price && product2_inventory > 0){
        System.out.println("Dispensing " + product2 + ".");
        System.out.println("Your change is: " + "$" + (cust_m - product2_price));
        product2_inventory--;
    }
    else{
        product2_inventory = 0;
        System.out.println("This product is currently unavailable.");
        System.out.println("Returning your money...");
    }
    
}

public void setCustMoney3(double cust_m){
    this.cust_money = cust_m;
    Scanner input = new Scanner(System.in);
    
    if(cust_m == product3_price && product3_inventory > 0){
       System.out.println("Dispensing " + product3 + "."); 
       product3_inventory--;
    }
    else if(cust_m < product3_price && product3_inventory > 0){
       System.out.println("Insufficient funds. Please add " + "$" + (product3_price - cust_m));
       System.out.println();
       System.out.print("Please input the remaining funds: $");
       double funds = input.nextDouble();
       if(funds == (product3_price - cust_m)){
          System.out.println("Dispensing " + product3 + "."); 
          product3_inventory--; 
           
       }
       
      }
    else if(cust_m > product3_price && product3_inventory > 0){
        System.out.println("Dispensing " + product3 + ".");
        System.out.println("Your change is: " + "$" + (cust_m - product3_price));
        product3_inventory--;
    }
    else{
         product3_inventory = 0;
         System.out.println("This product is currently unavailable.");
         System.out.println("Returning your money...");
    }
}

public void setCustMoney4(double cust_m){
    this.cust_money = cust_m;
    Scanner input = new Scanner(System.in);
    
    if(cust_m == product4_price && product4_inventory > 0){
       System.out.println("Dispensing " + product4 + "."); 
       product4_inventory--;
    }
    else if(cust_m < product4_price && product4_inventory > 0){
       System.out.println("Insufficient funds. Please add " + "$" + (product4_price - cust_m));
       System.out.println();
       System.out.print("Please input the remaining funds: $");
       double funds = input.nextDouble();
       if(funds == (product4_price - cust_m)){
          System.out.println("Dispensing " + product4 + "."); 
          product4_inventory--; 
           
       }
       
    }
    else if(cust_m > product4_price && product4_inventory > 0){
        System.out.println("Dispensing " + product4 + ".");
        System.out.println("Your change is: " + "$" + (cust_m - product4_price));
        product4_inventory--;
    }
    else{
         product4_inventory = 0;
         System.out.println("This product is currently unavailable.");
         System.out.println("Returning your money...");
         
    }
}
public void getCandyInfo(){
    System.out.println("Product: " + getproduct1() + " | " + "Price: " +  "$" + getproduct1_price() 
             + " | " + "Inventory: " + getproduct1_inventory());
                   
    System.out.println("Product: " + getproduct2() + " | " + "Price: " +  "$" + getproduct2_price() 
             + " | " + "Inventory: " + getproduct2_inventory());
                   
    System.out.println("Product: " + getproduct3() + " | " + "Price: " +  "$" + getproduct3_price()
             + " | " + "Inventory: " + getproduct3_inventory());
                   
    System.out.println("Product: " + getproduct4() + " | " + "Price: " +  "$" + getproduct4_price() 
             + " | " + "Inventory: " + getproduct4_inventory());
 }
 
 public void RefillInventory(){
       product1_inventory = 20;
       product2_inventory = 20;
       product3_inventory = 20;
       product4_inventory = 20;
    }
   
 public void displayInventory(){
    System.out.println(getproduct1() + " Inventory: " + getproduct1_inventory());
                   
    System.out.println(getproduct2() + " Inventory: " + getproduct2_inventory());
                   
    System.out.println(getproduct3() + " Inventory: " + getproduct3_inventory());
                   
    System.out.println(getproduct4() + " Inventory: " + getproduct4_inventory());
 } 
 

}
