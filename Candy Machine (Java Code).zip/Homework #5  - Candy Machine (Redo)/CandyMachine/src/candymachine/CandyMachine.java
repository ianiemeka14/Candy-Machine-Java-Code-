package candymachine;

import java.util.Scanner;

/**
 *
 * @author Isaiah Aniemeka
 */
public class CandyMachine {
   protected String product1;
   protected double product1_price;
   protected int product1_inventory;
   
   protected String product2;
   protected double product2_price;
   protected int product2_inventory;
   
   protected String product3;
   protected double product3_price;
   protected int product3_inventory;
   
   protected String product4;
   protected double product4_price;
   protected int product4_inventory;
   
   private double cust_money;
   
   

   
   


public CandyMachine(String p1, double p1_price, String p2, double p2_price, String p3, double p3_price, String p4, double p4_price){
   
    product1 = p1;
    product1_price = p1_price;
    
    
    product2 = p2;
    product2_price = p2_price;
    
    
    product3 = p3;
    product3_price = p3_price;
    
    
    product4 = p4;
    product4_price = p4_price;
    
    
    
    setproduct1Name(p1);
    setproduct1_Price(p1_price);
    
    
    setproduct2Name(p2);
    setproduct2_Price(p2_price);
    
    setproduct3Name(p3);
    setproduct3_Price(p3_price);
    
    setproduct4Name(p4);
    setproduct4_Price(p4_price);
    
    
    
    
    
    
}


public String getproduct1(){
  return product1;
}
public String getproduct2(){
  return product2;
}
public String getproduct3(){
  return product3;
}
public String getproduct4(){
    return product4;
}


public double getproduct1_price(){
  return product1_price;
}
public int getproduct1_inventory(){
    return product1_inventory;
}


public double getproduct2_price(){
  return product2_price;
}
public int getproduct2_inventory(){
    return product2_inventory;
}


public double getproduct3_price(){
  return product3_price;
}
public int getproduct3_inventory(){
    return product3_inventory;
}


public double getproduct4_price(){
    return product4_price;
}
public int getproduct4_inventory(){
    return product4_inventory;
}





public void setproduct1Name(String product1){
    this.product1 = product1;
} 
public void setproduct2Name(String product2){
    this.product2 = product2;
}
public void setproduct3Name(String product3){
    this.product3 = product3;
}
public void setproduct4Name(String product4){
    this.product4 = product4;
}


public void setproduct1_Price(double product1_price){
    this.product1_price = product1_price;
} 
public void setproduct1_Inventory(int product1_inventory){
    this.product1_inventory = product1_inventory;
}


public void setproduct2_Price(double product2_price){
    this.product2_price = product2_price;
}
public void setproduct2_Inventory(int product2_inventory){
    this.product2_inventory = product2_inventory;
}


public void setproduct3_Price(double product3_price){
    this.product3_price = product3_price;
}
public void setproduct3_Inventory(int product3_inventory){
    this.product3_inventory = product3_inventory;
}


public void setproduct4_Price(double product4_price){
    this.product4_price = product4_price;
}
public void setproduct4_Inventory(int product4_inventory){
    this.product4_inventory = product4_inventory;
}

public void runMachine(){
      int choice = 0;
        Scanner x = new Scanner(System.in);
        
        CandyMachine item = new CandyMachine("Candy", 1.25, "Chips", 2.00,"Gum", 1.75, "Cookies", 2.00);
        Dispenser selection = new Dispenser("Candy", 1.25, 20, "Chips", 2.00, 20, "Gum", 1.75, 20, "Cookies", 2.00, 20);
        CashRegister safebox = new CashRegister("Candy", 1.25, 20, "Chips", 2.00, 20, "Gum", 1.75, 20, "Cookies", 2.00, 20, 500.00);
        
         while(choice != 6){
            System.out.println("***Welcome to Chu's Candy Shop***");
            System.out.println("Please choose an item");
            System.out.println("1. Candy");
            System.out.println("2. Chips");
            System.out.println("3. Gum");
            System.out.println("4. Cookies");
            System.out.println("5. Update Vending Machine / View Info (Only accessible to owner)");
            System.out.println("6. Exit");
            System.out.print("Choice: ");
            choice = x.nextInt();
            System.out.println();
        
            
            if(choice == 1){
                System.out.print("Product: " + item.getproduct1() + " | " + "Price: " +  "$" + item.getproduct1_price() 
                   + " | " + "Inventory: " + selection.getproduct1_inventory());
                
                System.out.println();
                
                System.out.print("Please deposit " + "$" + item.getproduct1_price() + " for " + item.getproduct1() + " : $");
                double custmoney1 = x.nextDouble();
                if(selection.getproduct1_inventory() > 0 && custmoney1 > selection.getproduct1_price()){
                    selection.setCustMoney(custmoney1);
                    safebox.Money(custmoney1);
                }
                else if(selection.getproduct1_inventory() > 0 && custmoney1 == selection.getproduct1_price()){
                    selection.setCustMoney(custmoney1);
                    safebox.Money(custmoney1);
                }
                else if(selection.getproduct1_inventory() > 0 && custmoney1 < selection.getproduct1_price()){
                    selection.setCustMoney(custmoney1);
                    safebox.Money(custmoney1);
                }
                else if(selection.getproduct1_inventory() == 0){
                    selection.setCustMoney(custmoney1);
                    safebox.Money(0.00);
                }
                System.out.println();
            }
            if(choice == 2){
                System.out.print("Product: " + item.getproduct2() + " | " + "Price: " +  "$" + item.getproduct2_price() 
                   + " | " + "Inventory: " + selection.getproduct2_inventory());
                
                System.out.println();
                
                System.out.print("Please deposit " + "$" + item.getproduct2_price() + " for " + item.getproduct2() + " : $");
                double custmoney2 = x.nextDouble();
                if(selection.getproduct2_inventory() > 0 && custmoney2 > selection.getproduct2_price()){
                    selection.setCustMoney2(custmoney2);
                    safebox.Money2(custmoney2);
                }
                else if(selection.getproduct2_inventory() > 0 && custmoney2 == selection.getproduct2_price()){
                    selection.setCustMoney2(custmoney2);
                    safebox.Money2(custmoney2);
                }
                else if(selection.getproduct2_inventory() > 0 && custmoney2 < selection.getproduct2_price()){
                    selection.setCustMoney2(custmoney2);
                    safebox.Money2(custmoney2);
                }
                else if(selection.getproduct2_inventory() == 0){
                    selection.setCustMoney2(custmoney2);
                    safebox.Money2(0.00);
                }
                System.out.println();
            }
            if(choice == 3){
                System.out.print("Product: " + item.getproduct3() + " | " + "Price: " +  "$" + item.getproduct3_price() 
                   + " | " + "Inventory: " + selection.getproduct3_inventory());
                
                System.out.println();
                
                System.out.print("Please deposit " + "$" + item.getproduct3_price() + " for " + item.getproduct3() + " : $");
                double custmoney3 = x.nextDouble();
                if(selection.getproduct3_inventory() > 0 && custmoney3 > selection.getproduct3_price()){
                    selection.setCustMoney3(custmoney3);
                    safebox.Money3(custmoney3);
                }
                else if(selection.getproduct3_inventory() > 0 && custmoney3 == selection.getproduct3_price()){
                    selection.setCustMoney3(custmoney3);
                    safebox.Money3(custmoney3);
                }
                else if(selection.getproduct3_inventory() > 0 && custmoney3 < selection.getproduct3_price()){
                    selection.setCustMoney3(custmoney3);
                    safebox.Money3(custmoney3);
                }
                else if(selection.getproduct3_inventory() == 0){
                    selection.setCustMoney3(custmoney3);
                    safebox.Money3(0.00);
                }
                System.out.println();
            }
            if(choice == 4){
                System.out.print("Product: " + item.getproduct4() + " | " + "Price: " +  "$" + item.getproduct4_price() 
                   + " | " + "Inventory: " + selection.getproduct4_inventory());
                
                System.out.println();
                
                System.out.print("Please deposit " + "$" + item.getproduct4_price() + " for " + item.getproduct4() + " : $");
                double custmoney4 = x.nextDouble();
                if(selection.getproduct4_inventory() > 0 && custmoney4 > selection.getproduct4_price()){
                    selection.setCustMoney4(custmoney4);
                    safebox.Money4(custmoney4);
                }
                else if(selection.getproduct4_inventory() > 0 && custmoney4 == selection.getproduct4_price()){
                    selection.setCustMoney4(custmoney4);
                    safebox.Money4(custmoney4);
                }
                else if(selection.getproduct4_inventory() > 0 && custmoney4 < selection.getproduct4_price()){
                    selection.setCustMoney4(custmoney4);
                    safebox.Money4(custmoney4);
                }
                else if(selection.getproduct4_inventory() == 0){
                    selection.setCustMoney4(custmoney4);
                    safebox.Money4(0.00);
                }
                System.out.println(); 
                
            }
            if(choice == 5){
                System.out.print("Enter your username: ");
                String user = x.next();
                System.out.print("Please enter your password: ");
                String pass = x.next();
                
                System.out.println();
                
                if("machinelove32".equals(user) && "Mymachine@23".equals(pass)){
                   
                    selection.getCandyInfo();
                   
                    System.out.println();
                    
                    System.out.println("The amount of money in the safebox is:" + " " + "$" + Math.round(safebox.getMoney() * 100d)/100d);
                
                
                System.out.print("Do you want to refill your inventory?: ");
                String inventory = x.next();
                if("Yes".equals(inventory) || "yes".equals(inventory)){
                    System.out.print("Refilling inventory...");
                    System.out.println();
                    selection.RefillInventory();
                    
                    System.out.println();
                    
                    selection.displayInventory();
                    
                    System.out.println();
                }    
                else if("No".equals(inventory) || "no".equals(inventory)){
                    System.out.println("Skipping option...");
                    
                    System.out.println();
                    
                } 
                
            
                
                System.out.print("Do you want to put more money in the box?: ");
                String choicemoney = x.next();
                if("Yes".equals(choicemoney) || "yes".equals(choicemoney)){
                    
                
                    System.out.println("Processing...");
                    System.out.print("How much money do want to add?: ");
                    double addmoney = x.nextDouble();
                    System.out.println("Adding " + "$" + addmoney + " " + "to the money box...");
                    
                    safebox.addMoney(addmoney);
                    
                    System.out.println();
                    
                    System.out.println("Your new balance is: " + "$" + safebox.getMoney());
                    
                    System.out.println();    
                }
                else if("No".equals(choicemoney) || "no".equals(choicemoney)){
                    System.out.println();
                    
                    System.out.println("Skipping option...");
                    
                    System.out.println();
                    
                } 
                
                System.out.print("Do you want to take out money?: ");
                String choicemoney1 = x.next();
                if("Yes".equals(choicemoney1) || "yes".equals(choicemoney1)){
                    
                    System.out.println("Processing...");
                    System.out.print("How much money do want to take out?: $");
                    double submoney = x.nextDouble();
                    
                    System.out.println("Subtracting " + "$" + submoney + " " + "from the money box...");
                    safebox.subMoney(submoney);
                    
                    System.out.println();
                    
                    System.out.println("Your new balance is: " + "$" + safebox.getMoney());
                    
                    System.out.println();
                    
                    System.out.println("Returniing to main menu...");
                    
                    System.out.println();    
                }
                else if("No".equals(choicemoney1) || "no".equals(choicemoney1)){
                    System.out.println("Returniing to main menu...");
                    
                    System.out.println();       
            }
            if(choice == 6){
                System.out.println("Thanks you and come again soon!");
                
                
            }
            
            
    }
    }
    }
        
}


 
 
 
    
}

