package candymachine;
/**
 *
 * @author Isaiah Aniemeka
 */
public class Main {

   
    public static void main(String[] args) {
      CandyMachine run = new CandyMachine("Candy", 1.25, "Chips", 2.00,"Gum", 1.75, "Cookies", 2.00);
      
      run.runMachine();
    }
}
    
    

